public class Backend {
  public void processRequest(int data) {
    // ...
  }
}
