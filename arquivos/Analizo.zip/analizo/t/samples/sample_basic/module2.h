#ifndef _MODULE2_H_
#define _MODULE2_H_

void say_hello();
void say_bye();

#endif // _MODULE2_H_
