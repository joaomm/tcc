#include <stdio.h>
#include "module2.h"

void say_hello() {
  printf("Hello, world!\n");
}

void say_bye() {
  printf("Bye, cruel world!\n");
}
