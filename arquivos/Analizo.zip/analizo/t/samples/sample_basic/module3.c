#include "module3.h"
#include <stdio.h>

int variable = 15;

void callback() {
  printf("this is callback function");
}
