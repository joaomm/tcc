public class Retangle extends Tetragon {
  public int area () { 
    return (width * height); 
  }
}
