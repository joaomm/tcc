public class Cat extends Mammal {
  private String _name;
  public Cat(String name) {
    _name = name;
  }
  public String name() {
    return _name;
  }
}
