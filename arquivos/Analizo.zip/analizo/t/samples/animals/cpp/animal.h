#ifndef _ANIMAL_H_
#define _ANIMAL_H_

class Animal {
  public:
    virtual const char* name() = 0;
};

#endif
