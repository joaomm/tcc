class Printer1 {
  private String message;
  Printer1(String msg) {
    this.message = msg;
  }
}
