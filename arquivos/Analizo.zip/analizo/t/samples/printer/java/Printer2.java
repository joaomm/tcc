class Printer2 {
  private String message;
  Printer2(String message) {
    this.message = message;
  }
}
