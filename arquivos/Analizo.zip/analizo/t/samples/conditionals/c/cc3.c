void cc3() {
  if (something) {
    printf("ok\n");
  } else {
    if (otherthing) {
      printf("nope\n");
    }
  }
}
