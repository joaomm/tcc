void cc2() {
  if (something) {
    printf("ok\n");
  } else {
    printf("nope\n");
  }
}
